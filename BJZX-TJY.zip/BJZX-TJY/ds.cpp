#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
const int MAXN = 5e4 + 10;
int n, m, a[MAXN];

signed main() {
    freopen("ds.in", "r", stdin);
    freopen("ds.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        int op, l, r, k, t;
        cin >> op >> l >> r >> k >> t;
        int tmp = (1 << k);
        if (op == 1) {
            int w;
            cin >> w;
            for (int i = l; i <= r; i++)
                if (i % tmp == t) a[i] += w;
        } else {
            int res = 0;
            for (int i = l; i <= r; i++)
                if (i % tmp == t) res += a[i];
            cout << res << '\n';
        }
    }

    return 0;
}