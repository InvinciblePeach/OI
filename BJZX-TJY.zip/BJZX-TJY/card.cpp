#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
const int MAXN = 25, mod = 998244353;
int n, T, ans;
char a[MAXN];
bitset<MAXN> use;

void dfs(int id) {
    if (id == n + 1) {
        int cnt = 0, sum = 0;
        for (int i = 1; i <= n; i++)
            if (use[i]) cnt++, sum += int(a[i]);
        (ans += min(sum, (cnt + 1) >> 1)) %= mod;
        return;
    }
    use[id] = 1;
    dfs(id + 1);
    use[id] = 0;
    dfs(id + 1);
}

signed main() {
    freopen("card.in", "r", stdin);
    freopen("card.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    cin >> n >> T;
    for (int i = 1; i <= n; i++)
        cin >> a[i], a[i] -= '0';
    dfs(1);
    cout << ans << '\n';
    if (T) {
        for (int i = 1; i <= n; i++) {
            ans = 0;
            a[i] = 1 - a[i];
            dfs(1);
            cout << ans << ' ';
            a[i] = 1 - a[i];
        }
    }

    return 0;
}