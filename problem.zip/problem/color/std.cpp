#include <bits/stdc++.h>
using namespace std;

#define MAXN 1505000

int n,m,k;
int head[MAXN],to[MAXN],nxt[MAXN],ind;
void ins(int u,int v){
    nxt[++ind] = head[u];
    head[u] = ind;
    to[ind] = v;
}
#define pii pair<int,int>
#define fi first
#define se second

mt19937_64 rnder(0);
namespace check{
    int c[MAXN],flg = 1;
    struct DSU{
        int fa[MAXN],rnd[MAXN];
        void init(){
            for(int i = 1;i <= n + m;i ++)fa[i] = i,rnd[i] = rnder() % INT_MAX;
        }      
        int sta[MAXN];int top;
        int find(int x){
            while(fa[x] ^ x)x = fa[x];
            return x;
        }
        void merge(int x,int y){
            int fx = find(x),fy = find(y);
            if(rnd[fx] < rnd[fy])swap(fx,fy);
            sta[++top] = fx;
            fa[fx] = fy;
        }
        void undo(){
            fa[sta[top]] = sta[top];
            top --;
        }
    }dsu;
    #define l(x) (x << 1)
    #define r(x) ((x << 1) | 1)
    #define m(l,r) ((l + r) >> 1)
    struct seg_tree{
        vector<int> v[MAXN<<2];
        void m_ins(int x,int l0,int r0,int l,int r,int u){
            if(l <= l0 && r >= r0){
                // cout << l << ' ' << r << ' ' << l0 << ' ' << r0 << ' ' << u << '\n';
                v[x].push_back(u);
                return;
            }
            int mid = m(l0,r0);
            if(l <= mid)m_ins(l(x),l0,mid,l,r,u);
            if(r > mid)m_ins(r(x),mid + 1,r0,l,r,u);
        }
        void check(int x,int l0,int r0){
            int cnt = 0;
            for(int u : v[x]){
                for(int h = head[u];h;h = nxt[h]){
                    // cout << x << ' ' << "mer " << u << ' ' << to[h] << '\n';
                    int v = to[h];
                    cnt ++;
                    dsu.merge(u,v);
                }
            }
            if(l0 == r0){
                if(dsu.find(1) == dsu.find(n)){
                    // cerr << "col " << l0 << '\n';
                    flg = 0;                    
                }
                while(cnt --)dsu.undo();
                return;
            }
            int mid = m(l0,r0);
            check(l(x),l0,mid);
            check(r(x),mid+1,r0);
            while(cnt --)dsu.undo();//,cerr << "undo\n";
        }
    }seg;

    void solve(){
        dsu.init();


        for(int i = 1;i <= n;i ++){
            if(c[i] > 1)seg.m_ins(1,1,k,1,c[i]-1,i);
            if(c[i] < k)seg.m_ins(1,1,k,c[i]+1,k,i);
        }
        seg.check(1,1,k);
    }
}

namespace cons{
    int dis[MAXN],vis[MAXN];
    priority_queue<pii,vector<pii>,greater<pii> > pq;

    void solve(){
        pq.push({0,1});
        memset(dis,0x3f,sizeof dis);
        dis[1] = 0;
        while(pq.size()){
            int u = pq.top().se;
            pq.pop();
            if(vis[u])continue;
            vis[u] = 1;
            for(int h = head[u];h;h = nxt[h]){
                if(dis[to[h]] > dis[u] + 1){
                    dis[to[h]] = dis[u] + 1;
                    pq.push({dis[to[h]],to[h]});
                }
            }   
        }
        // cerr << dis[n] << '\n';
        if(dis[n] / 2 < (k - 1)){
            cout << "?\n";
            return;
        }
        cout << "NO\n";
        // for(int i = 1;i <= n;i ++)cout << dis[i]  << ' ';
        for(int i = 1;i <= n;i ++)cout << dis[i] / 2 % k + 1 << ' ';
        cout << '\n';
    }
}


signed main(){
    cin >> n >> m >> k;
    for(int i = 1;i <= m;i ++){
        int u,v;
        cin >> u >> v;
        ins(u,n + i);
        ins(n + i,u);
        ins(v,n + i);
        ins(n + i,v);
    }
    for(int i = 1;i <= n;i ++){
        cin >> check::c[i];
    }
    check::solve();
    if(check::flg){
        cout << "YES\n";
        cerr << "YES\n";
        return 0;
    }
    cons::solve();
}

/*
*/