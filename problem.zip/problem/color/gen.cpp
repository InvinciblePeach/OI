#include<bits/stdc++.h>
using namespace std;
#define int long long
mt19937_64 rnd(std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now()).time_since_epoch().count());

// mt19937_64 rnd(2189);
int gen(int x){
    if(!x)return 0;
    return rnd() % x + 1;
}
#define MAXN 1004000
int fa[MAXN];
vector<int> son[MAXN];
#define pii pair<int,int>
#define fi first
#define se second
vector<pii> e;
vector<int> id[MAXN];
int mxdep;
int n = 10,m = 10,k = 5;
void dfs(int x,int dis){
    if(x == n)mxdep = max(mxdep,dis);
    id[dis].push_back(x);
    for(int u : son[x]){
        dfs(u,dis + 1);
    }
}

vector<int> nxt[MAXN];
int dis[MAXN];
signed main(){
    n = 100,m = 300,k = 50;
    int k0 = 60,flg;
    cin >> n  >> k >> k0 >> flg;
    m = 3 * n;
    for(int i = 2;i <= n;i ++){
        int l = max(1ll,i - min(n/k,10ll)),r = i - 1;
        int f = l - 1 + gen(r - l + 1);
        e.push_back(rnd()%2?(pii){i,f}:(pii){f,i});
        son[f].push_back(i);
        // cerr << i << "=>" << f << '\n';
    }
    dfs(1,1);
    int num = max(1ll,k0 / 2);
    int len = mxdep / num;
    int eblk = (m - n + 1) / num, ere = (m - n + 1) % num;
    // cerr << mxdep << ' ' << len << ' ' << num << '\n';
    int l = 1;
    for(int i = 1;i <= num;i ++){
        int e_num = eblk + (i <= ere);
        int r = l + len + (i <= mxdep % num) - 1;
        assert(r <= mxdep);
        while(e_num --){
            int p0 = l - 1 + gen(r - l + 1),q0 = l - 1 + gen(r - l + 1);
            int p = id[p0][gen(id[p0].size()) - 1], q = id[q0][gen(id[q0].size())-1];
            e.push_back({p,q});
        }
        l = r + 1;
    }
    assert(e.size() == m);
    shuffle(e.begin(),e.end(),rnd);
    cout << n << ' ' << m << ' ' << k << '\n';
    for(int i = 0;i < m;i ++){
        cout << e[i].first << ' '<< e[i].second << '\n';
        nxt[e[i].first].push_back(e[i].second); 
        nxt[e[i].second].push_back(e[i].first); 
    }
    dis[1] = 1;
    queue<int> q;
    q.push(1);
    while(q.size()){
        int u = q.front();
        q.pop();
        for(int v : nxt[u]){
            if(dis[v])continue;
            dis[v] = dis[u] + 1;
            q.push(v);
        }
    }
    cerr << "dis n = " << dis[n] << "; k = " << k << ";\n";
    for(int i = 1;i <= n;i ++){
        cout << dis[i] % (flg ? (k - 1) : k) + 1 << ' ';
    }
    cout << '\n';
}