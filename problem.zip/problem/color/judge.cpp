#include "testlib.h"
#include<bits/stdc++.h>
using namespace std;
#define MAXN 500040
#define int long long

int n,m,k;
vector<int> nxt[MAXN];
int c[MAXN];
int vis[MAXN];

#define pii pair<int,int>
#define fi first
#define se second

mt19937_64 rnder(0);
namespace check{
    int flg = 1;
    struct DSU{
        int fa[MAXN<<1],rnd[MAXN<<1];
        void init(){
            for(int i = 1;i <= n + m;i ++)fa[i] = i,rnd[i] = rnder() % INT_MAX;
        }      
        int sta[MAXN<<1];int top;
        int find(int x){
            while(fa[x] ^ x)x = fa[x];
            return x;
        }
        void merge(int x,int y){
            int fx = find(x),fy = find(y);
            if(rnd[fx] < rnd[fy])swap(fx,fy);
            sta[++top] = fx;
            fa[fx] = fy;
        }
        void undo(){
            fa[sta[top]] = sta[top];
            top --;
        }
    }dsu;
    #define l(x) (x << 1)
    #define r(x) ((x << 1) | 1)
    #define m(l,r) ((l + r) >> 1)
    struct seg_tree{
        vector<int> v[MAXN<<2];
        void m_ins(int x,int l0,int r0,int l,int r,int u){
            if(l <= l0 && r >= r0){
                // cout << l << ' ' << r << ' ' << l0 << ' ' << r0 << ' ' << u << '\n';
                v[x].push_back(u);
                return;
            }
            int mid = m(l0,r0);
            if(l <= mid)m_ins(l(x),l0,mid,l,r,u);
            if(r > mid)m_ins(r(x),mid + 1,r0,l,r,u);
        }
        void check(int x,int l0,int r0){
            int cnt = 0;
            for(int u : v[x]){
                for(int v : nxt[u]){
                    cnt ++;
                    dsu.merge(u,v);
                }
            }
            if(l0 == r0){
                if(dsu.find(1) == dsu.find(n)){
                    // cerr << "col " << l0 << '\n';
                    flg = 0;                    
                }
                while(cnt --)dsu.undo();
                return;
            }
            int mid = m(l0,r0);
            check(l(x),l0,mid);
            check(r(x),mid+1,r0);
            while(cnt --)dsu.undo();//,cerr << "undo\n";
        }
    }seg;

    void solve(){
        dsu.init();


        for(int i = 1;i <= n;i ++){

            if(c[i] > 1)seg.m_ins(1,1,k,1,c[i]-1,i);
            if(c[i] < k)seg.m_ins(1,1,k,c[i]+1,k,i);
        }
        seg.check(1,1,k);
    }

	void reset(){
		for(int i = 1;i < MAXN << 2;i ++)seg.v[i].clear();
		flg = 1;
	}
}
int dis[MAXN];
signed main(int argc,char* argv[]) {
	registerLemonChecker(argc,argv);
	n = inf.readInt();m = inf.readInt();k = inf.readInt();
	int u,v;
	for(int i = 1;i <= m;i ++){
		u = inf.readInt();v = inf.readInt();
		nxt[u].push_back(n + i),nxt[v].push_back(n + i);
        nxt[n + i].push_back(u);
        nxt[n + i].push_back(v);
	}
	for(int i = 1;i <= n;i ++){
		c[i] = inf.readInt();
        // cout << i << ' ' << c[i] << '\n';
	}
	check::solve();
	string str = ouf.readLine();
	if(str != "YES" && str != "NO" && str != "?"){
		quitf(_wa,"did you answer by random?");
	}
	if(check::flg){
		if(str == "YES"){
			quitf(_ok,"good");
		}else{
			quitf(_wa,"did you check by random?");
		}
	}
	vis[1] = 1;
    dis[1] = 1;
	queue<int> q;
	q.push(1);
	while(q.size()){
		int u = q.front();
		q.pop();
		for(int v : nxt[u]){
			if(dis[v])continue;
			dis[v] = dis[u] + 1;
            // cerr << v << ' ' << dis[v] << '\n';
			q.push(v);
		}
	}
	// cerr << dis[n] << ' ' <<k << '\n';
	if(dis[n] / 2 < k - 1){
		if(str == "?"){
			quitf(_ok,"good");
		}else{
            quitp(0.6,"did you construct by imagination?");	
		}
	}
	for(int i = 1;i <= n;i ++){
		c[i] = ouf.readInt(1,k);
	}
	check::reset();
	check::solve();
	if(!check::flg){
        quitp(0.6,"did you construct by random?");	
	}
	quitf(_ok,"good");
	return 0;
}
