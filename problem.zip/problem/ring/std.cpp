#include <bits/stdc++.h>
using namespace std;

#define MAXN 150
#define int long long
int n,m;
const int P = 998244353;
int qpow(int x,int y){
    int res=  1;
    while(y){
        if(y & 1)res = res * x % P;
        y >>= 1;
        x = x * x % P;
    }
    return res;
}

struct equation{
	int n;
	int arr[MAXN][MAXN];

    int R = 1;
    void swap(int i,int j){
        if(i==j)return;
        for(int k = 1;k <= n;k ++)::swap(arr[i][k],arr[j][k]);
        // cout<<i<<' '<<j << "end\n";
        R = -R;
    }

	int get(){
		for(int i = 1;i <= n;i ++){
            // cout << i << '\n';
            int ind = -1;
            for(int j = i;j <= n;j ++){
                if(arr[i][j]){
                    ind = j;
                    break;
                }
            }
            // cout << i << '\n';
            if(ind==-1)return 0;

			swap(i,ind);
            // cout << i << '\n';
            for(int j = i + 1;j <= n;j ++){
                assert(arr[i][i]);
                int k = - arr[j][i] * qpow(arr[i][i],P - 2) % P;;
                k = (P + k) % P;
                for(int q = i;q <= n;q ++){
                    arr[j][q] += k * arr[i][q] % P;
                    arr[j][q] %= P;
                }
            }
            // cout << i << '\n';
		}
        R = (R + P) % P;
 		for(int i = 1;i <= n;i ++){
            R *= arr[i][i];
            R %= P;
		}
        return R;
	}
}eq;


signed main(){
    // freopen("ring.in","r",stdin);
    // freopen("ring.out","w",stdout);
    int n,m,u,v,w;
    cin >> n >> m;
    for(int i = 1;i <= m;i ++){
        cin >> u >> v >> w;
        assert(u ^ v);
        eq.arr[u][v] += w == 1 ? -1 : 1;
        eq.arr[u][u] ++;
    }
    for(int i = 1;i <= n;i ++){
        for(int j = 1;j <= n;j ++){
            eq.arr[i][j] = (eq.arr[i][j] + P) % P;
        }
    }
    eq.n = n;
    cout << eq.get() << '\n';
}