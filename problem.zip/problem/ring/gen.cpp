#include<bits/stdc++.h>
using namespace std;
#define int long long
mt19937_64 rnd(std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now()).time_since_epoch().count());

signed main(){
    int n,m,w;
    n = 5,m = 20;
    cin >> n >> m >> w;
    cout << n << ' ' << m << '\n';
    for(int i = 1;i <= m;i ++){
        int u = rnd() % n + 1;
        int v = rnd() % (n - 1) + 1;
        if(v >= u) v ++;
        cout << u << ' ' << v << ' ' << (w ? w - 1 : rnd() % 2) << '\n';
    }
} 