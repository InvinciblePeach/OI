#include <bits/stdc++.h>
using namespace std;

#define MAXN 1005000
#define int long long

const int P = 1e9 + 7;
int f[MAXN],x[MAXN],y[MAXN];

signed main(){
    // freopen("counting.in","r",stdin);
    // freopen("counting.out","w",stdout);
    int lst = 0;
    int n;
    cin >> n;
    f[0] = 1,f[1] = 2,f[2] = 3;
    for(int i = 1;i <= n;i ++){
        cin >> x[i] >> y[i];
        if(i > 2 && x[i] - x[i-1] == x[i-1] - x[i-2]){
            lst = i - 2;
        }
        if(i > 2)f[i] = (f[i-1] + f[lst]) % P;
        // if(i > 2) cout << i << ' ' << lst << ' ' << f[i] << '\n';
    }
    cout << f[n] << '\n';
}