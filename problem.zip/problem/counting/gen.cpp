#include<bits/stdc++.h>
using namespace std;
#define int long long
mt19937_64 rnd(std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now()).time_since_epoch().count());
int gen(int x){
    if(!x)return 0;
    return rnd() % x + 1;
}

signed main(){
    cin.tie(0),cout.tie(0),ios::sync_with_stdio(0);
    int n = 100000;
    int x = 0,y = 0,lst = 1;
    cout << n << '\n' << x << ' ' << y << '\n';     
    for(int i = 2;i <= n;i ++){
        if(gen(10) == 1)lst ^= 1;
        lst ^= 1;
        if(lst) x ++;
        else y ++;
        cout << x << ' ' << y << '\n';
    }
}