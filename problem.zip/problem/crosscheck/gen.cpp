#include<bits/stdc++.h>
using namespace std;
#define int long long
mt19937_64 rnd(std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now()).time_since_epoch().count());
int gen(int x){
    if(!x)return 0;
    return rnd() % x + 1;
}
std::binomial_distribution<> d(4, 0.5);
int genlower(int x){
    if(!x)return 0;
    int res = d(rnd);
    if(res < x)res = 2*x - 1 - res;
    return res - x + 1;
}
int len[5000400];

signed main(){
    int n = 10,mV = 10,sum = 20;
    cin >> n >> mV >> sum;
    d = std::binomial_distribution<>(2*mV-1,0.5);

    int q = 0,cur = 1;
    while(sum){
        q ++;
        len[q] = sum > cur ? (cur ++) : min({sum,genlower(mV),n});
        sum -= len[q];
    }
    cout << n << ' ' << q << '\n';
    string s(n,'0'),t(n,'0');
    {
        int p = min((n+4)/5,100ll);
        int len[100];
        for(int i = 0;i < p;i ++)len[i] = 1;
        int tmp = n - p;
        while(tmp --)len[gen(p) - 1] ++;
        cur = 0;
        int per = gen(5);
        for(int i = 0;i < p;i ++){
            // cerr << i << ' ' << len[i] << '\n';
            for(int j = 0;j < len[i];j ++)
                s[cur ++] = ((j / per) % 26 + 'a');
        }
        
        
        for(int i = 0;i < p;i ++)len[i] = 1;
        tmp = n - p;
        while(tmp --)len[gen(p) - 1] ++;
        cur = 0;
        for(int i = 0;i < p;i ++){
            for(int j = 0;j < len[i];j ++)
                t[cur ++] = ((j / per) % 26 + 'a');
        }
    } 
    cout << s << '\n' << t << '\n';
    for(int j= 1;j <= q;j ++){
        int k = gen(n - len[j] + 1) - 1;
        for(int i = 0;i < len[j];i ++)cout << s[k+i];
        cout << '\n';
        for(int i = 0;i < len[j];i ++)cout << t[k+i];
        cout << '\n';
    }
}