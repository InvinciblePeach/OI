#include <bits/stdc++.h>
using namespace std;

#define MAXN 1005000
#define MAXM 5005000
#define MAXV 30
struct AC{
    int trans[MAXN][MAXV];
    int fail[MAXN];
    vector<int> son[MAXN];
    int cnt = 1;
    int ins(string str){
        int u = 1;
        for(int i = 0;i < str.length();i ++){
            int c = str[i] - 'a';
            if(!trans[u][c])trans[u][c] = ++cnt;
            u = trans[u][c];
        }
        return u;
    }
    void build(){
        queue<int> q;
        q.push(1);
        fail[1] = 1;
        while(q.size()){
            int u = q.front();
            // cout << u << '\n';
            q.pop();
            if(u == 1){
                for(int c = 0;c < 26;c ++){
                    int v = trans[u][c];
                    if(v){
                        fail[v] = 1;
                        q.push(v);
                    }else trans[u][c] = 1;
                }
            }else{
                for(int c = 0;c < 26;c ++){
                    int v = trans[u][c];
                    if(v){
                        fail[v] = trans[fail[u]][c];
                        q.push(v);
                    }else trans[u][c] = trans[fail[u]][c];
                }
            }
        }
        for(int i = 2;i <= cnt;i ++)son[fail[i]].push_back(i);
    }
    int dfn[MAXN],ti,ed[MAXN];
    void dfs(int x){
        dfn[x] = ++ti;
        for(int i : son[x])dfs(i);
        ed[x] = ti;
    }
}ac1,ac2;

string s,t;
int poss[MAXN],post[MAXN];

struct opti{
    int opt,x,y,d,id;
}arr[MAXM];
int cnt;

void add(int x1,int y1,int x2,int y2,int x){
    arr[++cnt] = {1,x1-1,y1-1,1,x};
    arr[++cnt] = {1,x2,y1-1,-1,x};
    arr[++cnt] = {1,x1-1,y2,-1,x};
    arr[++cnt] = {1,x2,y2,1,x};
}

struct BIT{
    int lbit(int x){
        return x & (-x);
    }
    int arr[MAXN];
    void m_add(int pos,int d){
        for(;pos < MAXN;pos += lbit(pos)){
            arr[pos] += d;
        }
    }
    int q_sum(int pos){
        int res = 0;
        for(;pos;pos -= lbit(pos))res += arr[pos];
        return res;
    }
}bit;

int ans[MAXN];

signed main(){
    freopen("crosscheck.in","r",stdin);
    freopen("crosscheck.out","w",stdout);
    double nw = clock();
    cin.tie(0),cout.tie(0),ios::sync_with_stdio(0);
    int n,m,q;
    cin >> n >> q;
    cin >> s >> t;
    for(int i = 1;i <= q;i ++){
        string S,T;
        cin >> S >> T;
        poss[i] = ac1.ins(S),post[i] = ac2.ins(T);
    }
    // cerr << "=====\n";
    ac1.build(),ac2.build();
    // cerr << "=====\n";
    ac1.dfs(1),ac2.dfs(1);
    // cerr << "=====\n";
    int u = 1,v = 1;
    for(int i = 0;i < n;i ++){
        u = ac1.trans[u][s[i]-'a'];
        v = ac2.trans[v][t[i]-'a'];
        // cout << "add " << ac1.dfn[u] << ' ' << ac2.dfn[v]<< '\n';
        arr[++cnt] = {0,ac1.dfn[u],ac2.dfn[v],0,0};
    }
    for(int i = 1;i <= q;i ++){
        // cout << "que " << ac1.dfn[poss[i]] << ' '<< ac2.dfn[post[i]] << ' ' << ac1.ed[poss[i]] << ' ' << ac2.ed[post[i]] << '\n';
        add(ac1.dfn[poss[i]],ac2.dfn[post[i]],ac1.ed[poss[i]],ac2.ed[post[i]],i);
    }
    sort(arr + 1,arr + cnt + 1,[](const opti x,const opti y){
        if(x.x ^ y.x)return x.x < y.x;
        return x.opt < y.opt;
    });
    for(int i = 1;i <= cnt;i ++){
        // cout << 
        if(!arr[i].opt){
            bit.m_add(arr[i].y,1);
        }else{
            ans[arr[i].id] += arr[i].d * bit.q_sum(arr[i].y);
        }
    }

    for(int i = 1;i <= q;i ++){
        cout << ans[i] << '\n';
    }
    cerr << (clock() - nw) / CLOCKS_PER_SEC << "s\n";
}

/*
7 2 2
abbaaaa
baabbba
aa
bb
ba
ab
*/