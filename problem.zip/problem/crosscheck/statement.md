## 双匹配 (crosscheck)

时间限制: 2s, 空间限制: 512Mb

### 题目描述

给定长度为 $n$ 的字符串 $s,t$ , $q$ 次询问, 每次询问给定长度为 $m_i$ 的字符串 $S_i,T_i$, 查询有多少个下标 $k\in[1,n-m_i+1]$, 使得 $s_{k\dots k+m_i-1}=S_i,t_{k\dots k+m_i-1}=T_i$. 其中 $s_{i\dots j}$ 表示字符串 $s$ 被区间 $[i,j]$ 截得的子串.

### 输入格式

**从文件 `crosscheck.in` 中读入数据.**

第一行两个整数 $n,q$, 分别表示 $s,t$ 长度, 询问次数;

第二行有一个长度为 $n$ 的字符串, 表示 $s$;

第三行有一个长度为 $n$ 的字符串, 表示 $t$;

接下来 $q$ 次询问, 每次询问输入两行, 每行一个长度为 $m_i$ 的字符串 $S_i,T_i$. $m_i$ 并不在输入中给出, 需要由对应行的字符串长度计算得出.


### 输出格式

**输出到文件 `crosscheck.out` 中.**

输出 $q$ 行, 每行一个整数, 表示这次询问的答案.

### 输入输出样例

**样例 1 输入**

```
10 2
aaabaababa
baabbbbbab
ba
bb
ab
ab
```

**样例 1 输出**

```
2
1
```

**样例 1 解释**

对于第一组询问, 下标 $4,7$ 是合法的, 共有两个.


**样例 2**

见下发文件中的 `crosscheck/ex_crosscheck2.in` 与 `crosscheck/ex_crosscheck2.out`, 该样例满足 $\sum m_i,n \leq 10^2$.

**样例 3**

见下发文件中的 `crosscheck/ex_crosscheck3.in` 与 `crosscheck/ex_crosscheck3.out`, 该样例满足 $\sum m_i,n \leq 10^6$.

### 数据范围与约定

对于 $30\%$ 的数据, $\sum m_i,n \leq 10^2$.

对于 $60\%$ 的数据, $\sum m_i,n \leq 3\times 10^3$.

对于 $100\%$ 的数据, $1 \leq m_i \leq n \leq 10^6, 1 \leq \sum m_i \leq 10^6$. 所有字符串中只包含小写字母.