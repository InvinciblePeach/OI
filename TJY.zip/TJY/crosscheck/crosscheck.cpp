#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

const int MAXN = 1e6 + 10;
int n, m = 1360, p, q, a[MAXN];
int rk[MAXN << 1], sa[MAXN << 1], cnt[MAXN], tmp[MAXN], id[MAXN];
int height[MAXN];
string s, t;

bool ls(const int &len, const int *x, const int *y) {
    for (int i = 1; i <= len; i++) {
        if (x[i] < y[i]) return true;
        else if (x[i] > y[i]) return false;
    }
    return false;
}

bool gs(const int &len, const int *x, const int *y) {
    for (int i = 1; i <= len; i++) {
        if (x[i] > y[i]) return true;
        else if (x[i] < y[i]) return false;
    }
    return false;
}

signed main() {
    freopen("crosscheck.in", "r", stdin);
    freopen("crosscheck.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    cin >> n >> q;
    cin >> s >> t;
    for (int i = 1; i <= n; i++)
        a[i] = (s[i - 1] - 'a' + 27) * (t[i - 1] - 'a' + 1);

    for (int i = 1; i <= n; i++) cnt[rk[i] = a[i]]++;
    for (int i = 1; i <= m; i++) cnt[i] += cnt[i - 1];
    for (int i = n; i; i--) sa[cnt[rk[i]]--] = i;

    for (int len = 1; len < n; len <<= 1, m = p) { // SA
        int cur = 0;
        for (int i = n - len + 1; i <= n; i++)
            id[++cur] = i;
        for (int i = 1; i <= n; i++)
            if (sa[i] > len) id[++cur] = sa[i] - len;

        memset(cnt, 0, sizeof(cnt));
        for (int i = 1; i <= n; i++)
            cnt[rk[i]]++;
        for (int i = 1; i <= m; i++)
            cnt[i] += cnt[i - 1];
        for (int i = n; i; i--)
            sa[cnt[rk[id[i]]]--] = id[i];

        p = 0;
        memcpy(tmp, rk, sizeof(tmp));
        for (int i = 1; i <= n; i++) {
            if (tmp[sa[i]] == tmp[sa[i - 1]] &&
                tmp[sa[i] + len] == tmp[sa[i - 1] + len])
                rk[sa[i]] = p;
            else
                rk[sa[i]] = ++p;
        }

        if (p == n) break;
    }

    while (q --> 0) {
        static int len, b[MAXN];
        static string S, T;
        cin >> S >> T;
        len = S.size();
        for (int i = 1; i <= len; i++)
            b[i] = (S[i - 1] - 'a' + 27) * (T[i - 1] - 'a' + 1);
        b[len + 1] = 0;

        int l = 1, r = n + 1;
        while (l < r) {
            int mid = (l + r) >> 1;
            if (gs(len, b, a + sa[mid] - 1)) {
                l = mid + 1;
            } else {
                r = mid;
            }
        }
        // cerr << l << "done\n";
        int tmp = l;
        l = 1, r = n + 1;
        while (l < r) {
            int mid = (l + r) >> 1;
            if (ls(len, b, a + sa[mid] - 1)) {
                r = mid;
            } else {
                l = mid + 1;
            }
        }
        // cerr << l << "done\n";
        cout << l - tmp << '\n';
    }

    return 0;
}
/*
#include <bits/stdc++.h>
#define int long long

using namespace std;

const int MAXN = 2e4 + 10;
int n, m, p, ans, s[MAXN];

signed main() {
	while (cin >> n) {
		if (!n) break;
		for (int i = 1; i <= n; i ++)
			cin >> s[i];
		for (int i = 1; i < n; i ++) s[i] = s[i + 1] - s[i] + 90;
		n --;
		m = 210;

		for (int i = 1; i <= n; i ++) cnt[rk[i] = s[i]] ++;
		for (int i = 1; i <= m; i ++) cnt[i] += cnt[i - 1];
		for (int i = n; i; i --) sa[cnt[rk[i]] --] = i;

		for (int len = 1; len < n; len <<= 1, m = p) { // SA
			int cur = 0;
			for (int i = n - len + 1; i <= n; i ++) id[++ cur] = i;
			for (int i = 1; i <= n; i ++)
				if (sa[i] > len) id[++ cur] = sa[i] - len;

			memset(cnt, 0, sizeof(cnt));
			for (int i = 1; i <= n; i ++) cnt[rk[i]] ++;
			for (int i = 1; i <= m; i ++) cnt[i] += cnt[i - 1];
			for (int i = n; i; i --) sa[cnt[rk[id[i]]] --] = id[i];

			p = 0;
			memcpy(tmp, rk, sizeof(tmp));
			for (int i = 1; i <= n; i ++) {
				if (tmp[sa[i]] == tmp[sa[i - 1]] &&
						tmp[sa[i] + len] == tmp[sa[i - 1] + len])
					rk[sa[i]] = p;
				else
					rk[sa[i]] = ++ p;
			}

			if (p == n) break;
		}

		for (int i = 1, k = 0; i <= n; i ++) { // Height
			if (rk[i] == 0) continue;
			if (k) k --;
			while (s[i + k] == s[sa[rk[i] - 1] + k]) k ++;
			height[rk[i]] = k;
		}

		int l = 0, r = n;
		while (l < r) {
			int mid = (l + r) >> 1;

			bool flag = false;
			int mx = sa[1], mn = sa[1];
			for (int i = 2; i <= n; i ++) {
				if (height[i] < mid) mx = mn = sa[i];
				else {
					mn = min(mn, sa[i]);
					mx = max(mx, sa[i]);
					if (mx - mn > mid) {
						flag = true;
						break;
					}
				}
			}

			if (flag) ans = mid, l = mid + 1;
			else r = mid;
		}

		if (ans < 4) cout << 0 << endl;
		else cout << ans + 1 << endl;

	}
	return 0;
}
    */