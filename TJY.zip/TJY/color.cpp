#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

const int MAXN = 1e5 + 10;
int n, m, k, w[MAXN], dep[MAXN], fa[MAXN];
vector<int> g[MAXN];
bitset<MAXN> vis, cnt;

int get(int x) {
    if (fa[x] == x) return x;
    return fa[x] = get(fa[x]);
}

void merge(int a, int b) {
    if (dep[a] < dep[b]) swap(a, b);
    fa[get(b)] = get(a);
}

void bfs() {
    queue<int> q;
    dep[1] = 1;
    q.emplace(1);
    while (q.size()) {
        int u = q.front();
        q.pop();
        for (auto v : g[u]) {
            if (u != 1 && v != n && u != n && v != 1) merge(u, v);
            if (dep[v]) continue;
            dep[v] = dep[u] + 1;
            q.emplace(v);
        }
    }
}

bool check() {
    for (int i = 2; i < n; i++) {
        if (vis[i]) continue;
        static queue<int> q;
        static unordered_set<int> st[MAXN];
        st[1].emplace(w[1]);
        int rt = get(i), mx = 0;
        if (vis[rt]) continue;
        q.emplace(rt);
        while (q.size()) {
            int u = q.front();
            q.pop();
            st[dep[u]].emplace(w[u]);
            vis[u] = 1;
            if (dep[u] > dep[n]) continue;
            mx = max(dep[u], mx);
            for (auto v : g[u]) {
                if ((dep[v] < dep[u]) || vis[v] || get(u) != get(v)) continue;
                q.emplace(v);
            }
        }
        int num = 2;
        cnt[w[1]] = cnt[w[n]] = 1;
        for (int i = 1; i <= mx; i++) {
            if (st[i].size() == 1) {
                if (!cnt[*st[i].begin()]) num++;
                cnt[*st[i].begin()] = 1;
            }
            st[i].clear();
        }
        cnt.reset();
        if (num < k)
            return false;
    }
    return true;
}

signed main() {
    freopen("color.in", "r", stdin);
    freopen("color.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    cin >> n >> m >> k;
    for (int i = 1, u, v; i <= m; i++) {
        cin >> u >> v;
        if (u == v) continue;
        g[u].emplace_back(v);
        g[v].emplace_back(u);
    }
    for (int i = 1; i <= n; i++) cin >> w[i];
    for (int i = 1; i <= n; i++) fa[i] = i;

    bfs();

    if (dep[n] < k) return cout << "?\n", 0;

    if (check()) {
        cout << "YES\n";
    } else {
        cout << "NO\n";
        for (int i = 1; i <= n; i++)
            cout << (dep[i] % k == 0 ? k : dep[i] % k) << " \n"[i == n];
    }

    return 0;
}

/*
大胆猜测：分层之后每一个“联通块”至少要有 $k$ 层每层都相同，且层与层不相同
证明不会
*/