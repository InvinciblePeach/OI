#include <bits/stdc++.h>
#define int long long

using namespace std;

const int MAXN = 1e5 + 10, mod = 1e9 + 7;
int n, x[MAXN], y[MAXN], dp[MAXN], lst = 1;

signed main() {
    freopen("counting.in", "r", stdin);
    freopen("counting.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    cin >> n;
    if (n == 1) cout << "2\n";
    dp[0] = 2, dp[1] = 3;
    cin >> x[0] >> y[0];
    cin >> x[1] >> y[1];
    for (int i = 2; i < n; i++) {
        cin >> x[i] >> y[i];
        if (x[i] - x[i - 1] == x[i - 1] - x[i - 2] && y[i] - y[i - 1] == y[i - 1] - y[i - 2]) {
            dp[i] = (dp[i - 1] + dp[i - 2]) % mod;
            lst = i;
        } else {
            dp[i] = (dp[i - 1] + (lst - 2 >= 0 ? dp[lst - 2] : 1)) % mod;
        }
    }
    cout << dp[n - 1] << '\n';

    return 0;
}